package com.example.capcheck

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.ImageFormat
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics as CC
import android.hardware.camera2.CameraManager
import android.hardware.camera2.params.DynamicRangeProfiles as DRP
import android.media.MediaCodecInfo.CodecProfileLevel
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val drNames = mapOf(
        DRP.STANDARD to "SDR",
        DRP.HLG10 to "HLG10",
        DRP.HDR10 to "HDR10",
        DRP.HDR10_PLUS to "HDR10+",
        DRP.DOLBY_VISION_10B_HDR_REF to "DV10 REF",
        DRP.DOLBY_VISION_10B_HDR_REF_PO to "DV10 REF-PO",
        DRP.DOLBY_VISION_10B_HDR_OEM to "DV10 OEM",
        DRP.DOLBY_VISION_10B_HDR_OEM_PO to "DV10 OEM-PO",
        DRP.DOLBY_VISION_8B_HDR_REF to "DV8 REF",
        DRP.DOLBY_VISION_8B_HDR_REF_PO to "DV8 REF-PO",
        DRP.DOLBY_VISION_8B_HDR_OEM to "DV8 OEM",
        DRP.DOLBY_VISION_8B_HDR_OEM_PO to "DV8 OEM-PO"
    )

    private var latestReport: String = ""
    private lateinit var reportView: TextView
    private lateinit var verdictView: TextView
    private lateinit var scanMetaView: TextView

    private val ink = Color.rgb(22, 31, 48)
    private val muted = Color.rgb(105, 119, 139)
    private val accent = Color.rgb(67, 97, 238)
    private val page = Color.rgb(246, 248, 252)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "CapCheck"
        window.statusBarColor = page
        window.navigationBarColor = page
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(page)
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipToPadding = false
            setPadding(0, 0, 0, dp(12))
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "CC"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = android.view.Gravity.CENTER
            background = rounded(accent, 14)
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val brandText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brandText.addView(TextView(this).apply {
            text = "CapCheck"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        })
        brandText.addView(TextView(this).apply {
            text = "Camera & video capability report"
            textSize = 12f
            setTextColor(muted)
        })
        brandRow.addView(brandText, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        content.addView(brandRow)

        val intro = TextView(this).apply {
            text = "See what your device exposes to Android apps — from HDR formats to camera resolutions and video encoders."
            textSize = 14f
            setTextColor(muted)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, dp(18), 0, dp(18))
        }
        content.addView(intro)

        val statusCard = card()
        statusCard.setPadding(dp(18), dp(18), dp(18), dp(18))
        statusCard.addView(TextView(this).apply {
            text = "DEVICE VERDICT"
            textSize = 11f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
        })
        verdictView = TextView(this).apply {
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(0, dp(8), 0, dp(8))
        }
        statusCard.addView(verdictView)
        scanMetaView = TextView(this).apply {
            textSize = 12f
            setTextColor(muted)
        }
        statusCard.addView(scanMetaView)
        content.addView(statusCard, marginParams(bottom = 16))

        val detailsHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        detailsHeader.addView(TextView(this).apply {
            text = "Full diagnostic"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }, LinearLayout.LayoutParams(0, dp(32), 1f))
        detailsHeader.addView(TextView(this).apply {
            text = "ON DEVICE"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            setPadding(dp(9), dp(6), dp(9), dp(6))
            background = rounded(Color.rgb(231, 236, 255), 20)
        })
        content.addView(detailsHeader, marginParams(bottom = 10))

        val reportCard = card()
        reportCard.setPadding(dp(14), dp(14), dp(14), dp(14))
        reportView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(Color.rgb(48, 61, 81))
            setTextIsSelectable(true)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        reportCard.addView(reportView)
        content.addView(reportCard)

        val privacy = TextView(this).apply {
            text = "Privacy note  ·  The report is generated on your phone. CapCheck does not upload it to a server. Sharing sends the text to the app you choose."
            textSize = 12f
            setTextColor(muted)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(2), dp(16), dp(2), dp(6))
        }
        content.addView(privacy)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        val refresh = Button(this).apply {
            text = "Scan again"
            isAllCaps = false
            setOnClickListener { refreshReport() }
        }
        actions.addView(refresh, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(8) })
        val share = Button(this).apply {
            text = "Share report"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(accent, 14)
            setOnClickListener { shareReport() }
        }
        actions.addView(share, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(8) })
        root.addView(actions)
        setContentView(root)
        refreshReport()
    }

    private fun refreshReport() {
        latestReport = try {
            buildReport()
        } catch (e: Exception) {
            "CapCheck could not complete the diagnostic.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown system error"}"
        }
        reportView.text = latestReport
        val verdict = latestReport.lineSequence().firstOrNull { it.startsWith("YES:") || it.startsWith("PARTIAL:") || it.startsWith("NO:") }
        verdictView.text = when {
            verdict == null -> "Report unavailable"
            verdict.startsWith("YES:") -> "Dolby Vision exposed"
            verdict.startsWith("PARTIAL:") -> "HDR support detected"
            else -> "No HDR format detected"
        }
        scanMetaView.text = "${Build.MANUFACTURER} ${Build.MODEL}  ·  Android ${Build.VERSION.RELEASE}"
    }

    private fun shareReport() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "CapCheck device report")
            putExtra(Intent.EXTRA_TEXT, latestReport)
        }
        startActivity(Intent.createChooser(send, "Share CapCheck report"))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Color.WHITE, 18, Color.rgb(230, 234, 242))
        elevation = dp(1).toFloat()
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun marginParams(bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildReport(): String {
        val sb = StringBuilder()
        val body = StringBuilder()
        val dvCams = mutableListOf<String>()
        val hdrCams = mutableListOf<String>()

        body.appendLine("== CAMERAS ==")
        val cm = getSystemService(CameraManager::class.java)
        for (id in cm.cameraIdList) {
            val c = cm.getCameraCharacteristics(id)
            val facing = when (c.get(CC.LENS_FACING)) {
                CC.LENS_FACING_BACK -> "back"
                CC.LENS_FACING_FRONT -> "front"
                else -> "external"
            }
            val caps = c.get(CC.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
            val logical = caps.contains(CC.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)
            body.appendLine("\n[ID $id] $facing${if (logical) " (logical multi-camera)" else ""}")
            body.appendLine("  focal: ${c.get(CC.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString()}")
            body.appendLine("  OIS modes: ${c.get(CC.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.joinToString()}  (1=on)")
            body.appendLine("  video stab modes: ${c.get(CC.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.joinToString()}  (1=on, 2=preview)")
            body.appendLine("  manual sensor: ${caps.contains(CC.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)}")
            body.appendLine("  RAW: ${caps.contains(CC.REQUEST_AVAILABLE_CAPABILITIES_RAW)}")
            if (logical) {
                for (pid in c.physicalCameraIds) {
                    val pc = cm.getCameraCharacteristics(pid)
                    body.appendLine("  physical $pid focal: ${pc.get(CC.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString()}")
                }
            }

            val profiles = c.get(CC.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)?.supportedProfiles
            if (profiles == null) {
                body.appendLine("  dynamic range: not reported (SDR only)")
            } else {
                val names = profiles.map { drNames[it] ?: "0x${it.toString(16)}" }
                body.appendLine("  dynamic range: ${names.joinToString()}")
                if (names.any { it.startsWith("DV") }) dvCams.add(id)
                if (names.any { it == "HLG10" || it == "HDR10" || it == "HDR10+" }) hdrCams.add(id)
            }

            val map = c.get(CC.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(MediaRecorder::class.java)
            if (sizes != null && map != null) {
                val biggest = sizes.maxByOrNull { it.width.toLong() * it.height }
                body.appendLine("  largest video size: $biggest")
                val uhd = sizes.firstOrNull { it.width == 3840 && it.height == 2160 }
                if (uhd != null) {
                    val dur = map.getOutputMinFrameDuration(MediaRecorder::class.java, uhd)
                    val fps = if (dur > 0) 1_000_000_000.0 / dur else 0.0
                    body.appendLine("  4K UHD: yes, max ~%.0f fps".format(fps))
                } else body.appendLine("  4K UHD: no")
                val p010 = map.getOutputSizes(ImageFormat.YCBCR_P010)
                body.appendLine("  P010 (10-bit) sizes: ${if (p010.isNullOrEmpty()) "none" else p010.size.toString() + " (max " + p010.maxByOrNull { it.width.toLong() * it.height } + ")"}")
            }
        }

        body.appendLine("\n== ENCODERS ==")
        val encoders = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.filter { it.isEncoder }
        var dvEncoder = false

        fun describe(mime: String, label: String) {
            body.appendLine("\n$label ($mime)")
            val list = encoders.filter { ci -> ci.supportedTypes.any { it.equals(mime, true) } }
            if (list.isEmpty()) { body.appendLine("  none"); return }
            if (mime == MediaFormat.MIMETYPE_VIDEO_DOLBY_VISION) dvEncoder = true
            for (ci in list) {
                val cap = ci.getCapabilitiesForType(mime)
                val vc = cap.videoCapabilities
                body.appendLine("  ${ci.name}${if (ci.isHardwareAccelerated) " [HW]" else ""}")
                val profs = cap.profileLevels.map { it.profile }.distinct().map { p ->
                    when (p) {
                        CodecProfileLevel.HEVCProfileMain -> "Main"
                        CodecProfileLevel.HEVCProfileMain10 -> "Main10"
                        CodecProfileLevel.HEVCProfileMain10HDR10 -> "Main10HDR10"
                        CodecProfileLevel.DolbyVisionProfileDvheStn -> "DV P5"
                        CodecProfileLevel.DolbyVisionProfileDvheDtb -> "DV P7"
                        CodecProfileLevel.DolbyVisionProfileDvheSt -> "DV P8"
                        else -> "0x${p.toString(16)}"
                    }
                }
                body.appendLine("    profiles: ${profs.joinToString()}")
                body.appendLine("    4K supported: ${vc.isSizeSupported(3840, 2160)}")
                val fr = runCatching { vc.getSupportedFrameRatesFor(3840, 2160) }.getOrNull()
                if (fr != null) body.appendLine("    4K fps range: $fr")
                body.appendLine("    bitrate range: ${vc.bitrateRange.lower / 1_000_000}-${vc.bitrateRange.upper / 1_000_000} Mbps")
            }
        }
        describe(MediaFormat.MIMETYPE_VIDEO_DOLBY_VISION, "Dolby Vision encoders")
        describe(MediaFormat.MIMETYPE_VIDEO_HEVC, "HEVC encoders")

        sb.appendLine("CapCheck: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine()
        sb.appendLine("== VERDICT ==")
        when {
            dvCams.isNotEmpty() && dvEncoder ->
                sb.appendLine("YES: Dolby Vision exposed via Camera2 on camera ID(s) ${dvCams.joinToString()}, DV encoder present.")
            hdrCams.isNotEmpty() ->
                sb.appendLine("PARTIAL: no Dolby Vision for third-party apps. HLG10/HDR10 available on ID(s) ${hdrCams.joinToString()}.")
            else ->
                sb.appendLine("NO: only SDR exposed to third-party apps.")
        }
        sb.appendLine()
        sb.append(body)
        return sb.toString()
    }
}
