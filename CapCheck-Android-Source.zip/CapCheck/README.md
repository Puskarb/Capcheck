# CapCheck for Android

CapCheck inspects the camera capabilities and video encoder profiles that Android exposes to third-party apps. It does not record video or upload the report.

## Features
- Modern, responsive native Android interface
- Camera IDs and lens facing, focal lengths, stabilization, manual sensor and RAW capabilities
- Camera dynamic-range profiles, maximum reported video size, 4K support and 10-bit P010 sizes
- Dolby Vision and HEVC encoder profiles, 4K support, frame-rate and bitrate ranges
- Clear verdict card, full selectable diagnostic text, rescan and Android share sheet
- No login, analytics, network permission or server upload

## Requirements
- Android Studio with Android SDK Platform 34
- JDK 17
- Android 13 (API 33) or newer, due to the project's current `minSdk = 33`

## Build a debug APK
Open this folder in Android Studio and allow Gradle sync, then run **Build > Build APK(s)**. Or install Gradle 8.7 and run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions
The workflow in `.github/workflows/build.yml` builds a debug APK on each push or manual run and uploads it as the `CapCheck-apk` workflow artifact. Download it from the successful workflow run's **Artifacts** section.

## Notes
- Device support reporting reflects Android's published Camera2/MediaCodec capabilities. It does not guarantee that every third-party camera app can record every listed format.
- A `NO` verdict means this app did not find the listed HDR formats exposed through these APIs; it is not a general statement about the phone's display or native camera app.
- The generated APK from GitHub Actions is a debug build, not a Play Store release-signed build.
